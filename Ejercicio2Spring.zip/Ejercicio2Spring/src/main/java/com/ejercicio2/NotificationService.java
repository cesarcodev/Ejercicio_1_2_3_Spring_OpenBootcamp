package com.ejercicio2;
import org.springframework.stereotype.Component;

@Component
public class NotificationService {

    public String imprimirSaludo(){
        return "Saludo Ejercicio 2 Spring!";
    }
}
