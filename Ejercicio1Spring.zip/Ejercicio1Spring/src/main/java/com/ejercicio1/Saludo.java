package com.ejercicio1;

public class Saludo {

    public String imprimirSaludo(){
        return "Hola Mundo Saludo Ejercicio 1 Spring!";
    }

}
