package com.ejercicio3.Ejercicio3Spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio3SpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
